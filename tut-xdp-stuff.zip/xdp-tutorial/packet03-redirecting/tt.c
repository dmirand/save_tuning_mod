#include <stdio.h>
#include <string.h>
#define ETH_ALEN 6

static unsigned char do_left(unsigned char val) {
	unsigned char leftside = 0xff;
		switch (val) {
			case '0':
				leftside = 0x00;
				break;
			case '1':
				leftside = 0x10;
				break;
			case '2':
				leftside = 0x20;
				break;
			case '3':
				leftside = 0x30;
				break;
			case '4':
				leftside = 0x40;
				break;
			case '5':
				leftside = 0x50;
				break;
			case '6':
				leftside = 0x60;
				break;
			case '7':
				leftside = 0x70;
				break;
			case '8':
				leftside = 0x80;
				break;
			case '9':
				leftside = 0x90;
				break;
			case 'a':
			case 'A':
				leftside = 0xa0;
				break;
			case 'b':
			case 'B':
				leftside = 0xb0;
				break;
			case 'c':
			case 'C':
				leftside = 0xc0;
				break;
			case 'd':
			case 'D':
				leftside = 0xd0;
				break;
			case 'e':
			case 'E':
				leftside = 0xe0;
				break;
			case 'f':
			case 'F':
				leftside = 0xf0;
				break;
			default:
				break;
			}

	return leftside;
}

static unsigned char do_right(unsigned char val) {
	unsigned char rightside  = 0xff;
	
		switch (val) {
			case '0':
				rightside = 0x00;
				break;
			case '1':
				rightside = 0x01;
				break;
			case '2':
				rightside = 0x02;
				break;
			case '3':
				rightside = 0x03;
				break;
			case '4':
				rightside = 0x04;
				break;
			case '5':
				rightside = 0x05;
				break;
			case '6':
				rightside = 0x06;
				break;
			case '7':
				rightside = 0x07;
				break;
			case '8':
				rightside = 0x08;
				break;
			case '9':
				rightside = 0x09;
				break;
			case 'a':
			case 'A':
				rightside = 0x0a;
				break;
			case 'b':
			case 'B':
				rightside = 0x0b;
				break;
			case 'c':
			case 'C':
				rightside = 0x0c;
				break;
			case 'd':
			case 'D':
				rightside = 0x0d;
				break;
			case 'e':
			case 'E':
				rightside = 0x0e;
				break;
			case 'f':
			case 'F':
				rightside = 0x0f;
				break;
			default:
				break;
			}

	return rightside;
}
static int parse_mac(char *str, unsigned char mac[ETH_ALEN])
{
        /* Assignment 3: parse a MAC address in this function and place the
         * result in the mac array */
		char *p = str;
		unsigned char leftside, rightside;
		int i = 0;
			
		while (p != NULL)
		{
			unsigned char one_octet[3] = {'\0','\0','\0'};
			p = strchr(p,':');
			if (p)
			{
				strncpy(one_octet,str, 2);
				p++;
				str = p;
				leftside = do_left(one_octet[0]);
				rightside = do_right(one_octet[1]);
				mac[i] = leftside | rightside;
			}
			else
				{	
					strncpy(one_octet,str, 2);
					leftside = do_left(one_octet[0]);
					rightside = do_right(one_octet[1]);
					mac[i] = leftside | rightside;
					continue;
				}
			i++;
		}

        return 0;
}

int main() 
{
	char *str = "fe:54:00:ad:b2:c0";
	unsigned char get_mac[ETH_ALEN];

	parse_mac(str,get_mac);

	printf("\n*****************\n");
	for (int i = 0; i < ETH_ALEN; i++)
			printf("%02x\n",get_mac[i]);

	return 0;
}
