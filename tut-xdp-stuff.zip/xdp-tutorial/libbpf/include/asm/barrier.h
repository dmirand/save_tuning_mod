/* SPDX-License-Identifier: (LGPL-2.1 OR BSD-2-Clause) */
#ifndef __ASM_BARRIER_H
#define __ASM_BARRIER_H

#include <linux/compiler.h>

#endif
